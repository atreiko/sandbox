[Привести к типу](https://codesandbox.io/s/task-js-functions-coerce-to-type-otv58)
[Счетчики](https://codesandbox.io/s/task-js-functions-counter)