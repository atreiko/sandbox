# Анимации

transitions, animations https://codepen.io/cyberbiont/pen/ZEbpjgJ

flip card https://codepen.io/cyberbiont/pen/JjYReRJ

perspective-based parallax (3D)  https://codepen.io/cyberbiont/pen/oNjzQOP





