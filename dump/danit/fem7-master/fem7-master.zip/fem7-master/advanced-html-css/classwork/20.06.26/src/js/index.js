console.log('Hello from index.js!')
