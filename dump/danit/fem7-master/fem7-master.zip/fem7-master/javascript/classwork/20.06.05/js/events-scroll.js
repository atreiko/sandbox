window.addEventListener('scroll', function () {
  document.getElementById('showScroll').innerHTML = scrollY + 'px';
});
