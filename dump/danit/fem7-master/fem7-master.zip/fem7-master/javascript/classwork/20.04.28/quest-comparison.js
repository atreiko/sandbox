const comparison = [
	!!"false" == !!"true",
	"true" == true,
	"true" === true,
	NaN == 1,
	NaN == NaN,
	NaN === NaN,
];
