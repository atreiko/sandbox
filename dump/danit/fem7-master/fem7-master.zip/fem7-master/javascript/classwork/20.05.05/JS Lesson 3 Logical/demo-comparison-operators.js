2 <= 1;
2 >= 1;
2 < 1;
2 > 1;
2 == 1;
2 === 1;

console.log("Виктория" > "Виктор");
console.log("Виктория" > "Виктор");

console.log(0 == false);
console.log("" == false);
