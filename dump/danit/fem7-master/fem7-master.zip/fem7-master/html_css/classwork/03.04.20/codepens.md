## Цвет

Градиент https://codepen.io/cyberbiont/pen/qBdwgVV

## Шрифты

@font-face https://codepen.io/cyberbiont/pen/XWbwreN

подключение шрифта с помощью <link> https://codepen.io/cyberbiont/pen/jOPRgdd

подключение шрифта с помощью @import https://codepen.io/cyberbiont/pen/jOPRgdd

CSS св-ва для шрифтов, font-variant https://codepen.io/cyberbiont/pen/YzXMMjV