CS250 - https://javarush.ru/quests/QUEST_HARVARD_CS50

Основы программирования и вообще все видосы Дмитрия Лаврика - https://www.youtube.com/user/dmitrylavr/playlists

Руководство по написанию кода от @mdo http://sadcitizen.me/code-guide/#css-classes

Css selectors https://htmldog.com/references/css/selectors/ 

10 полезных Git команд, которые облегчат работу https://proglib.io/p/10-tips-git/