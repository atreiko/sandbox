| Homework name                                                     | Date       |
|-------------------------------------------------------------------|------------|
| HW1 - Simple Photo                                                | 17.03.2020 |
| HW2 - Ramda                                                       | 20.03.2020 |
| HW3 - Milan                                                       | 27.03.2020 |
| HW4 - Journey                                                     | 31.03.2020 |
| HW5 - Tables                                                      | 31.03.2020 |
| HW6 - Design & Architecture                                       | 03.04.2020 |
| HW7 - Animation Star Wars, HW8 - Parallax-2                       | 07.04.2020 |
| HW1 - alert, prompt, confirm                                      | 13.05.2020 |
| HW2 - Find multiples                                              | 16.05.2020 |
| HW3 - Math function, HW16 - Factorial, HW17 - Fibonacci           | 20.05.2020 |
| HW4 - Create user, HW18 - Create student, HW19 - Clone object,    | 23.05.2020 |
| HW5 - User age and password, HW20 - Sprint panning                | 27.05.2020 |
| HW6 - Filter array, HW21 - Advanced filter                        | 00.00.2020 |
| HW7 - Show list on page                                           | 00.00.2020 |
| HW8 - Validate price HW9 - Tabs HW22 - Draw circle                | 00.00.2020 |
| HW10 - Show password,   HW11 - Highlight letters                  | 00.00.2020 |
| HW23 - Colored table, HW24 - Minesweeper, HW25 - Calculator       |            |
| HW12 - Cycled slider, HW13 - Change color theme, HW26 - JS slider | 00.00.2020 |
| HW14 -  jQuery effects                                            | 00.00.2020 |