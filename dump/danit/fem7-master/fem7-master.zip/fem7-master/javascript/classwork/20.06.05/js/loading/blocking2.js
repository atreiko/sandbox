console.log('blocking2');
document.addEventListener('DOMContentLoaded', () => {
  console.log('DCL');
});
