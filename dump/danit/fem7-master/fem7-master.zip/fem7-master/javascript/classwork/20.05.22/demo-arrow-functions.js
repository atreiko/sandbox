/* Стрелочные функции */

const arrowFn = (arg1, arg2) => {
  return arg1 + arg2;
};

const arrowFn2 = (arg1) => ++arg1;

console.log(arrowFn2(10));
