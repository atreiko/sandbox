https://codesandbox.io/s/task-js-print-key-code-ejvn9 (решение: https://codesandbox.io/s/task-js-print-key-code-solution-hjz62)
https://codesandbox.io/s/task-js-menu-active-fgy4g?file=/task/requirements.mdPractice (решение: https://codesandbox.io/s/task-js-menu-active-solution-z8jc0)

https://codesandbox.io/s/task-js-countdown-btxzi?file=/task/task.js (решение: https://codesandbox.io/s/task-js-countdown-solution-5qjo8?file=/task/task.js)