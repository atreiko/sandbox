console.log(`deferred script reporting: body is`, document.body);
