## Задание

Переделать домашнее задание 9 (табы), используя jQuery

#### Литература:
- [jQuery для начинающих](http://anton.shevchuk.name/javascript/jquery-for-beginners/)
