const outsideTemperature = 27;
console.log(`Hello from Miami!${outsideTemperature}`);
