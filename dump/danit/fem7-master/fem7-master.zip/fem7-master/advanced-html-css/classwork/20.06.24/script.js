// const moment = require('moment');
const { argv } = require('yargs');

// const helloween = moment([2011, 9, 31]); // October 31st
// console.log(helloween.fromNow());
console.log(argv);
