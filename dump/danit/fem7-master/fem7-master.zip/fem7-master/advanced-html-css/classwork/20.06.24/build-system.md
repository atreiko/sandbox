https://github.com/cyberbiont/build-system-students

https://codesandbox.io/s/build-system-students-yxfmx
