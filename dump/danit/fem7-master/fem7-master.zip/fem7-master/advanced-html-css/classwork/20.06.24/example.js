const helloWorldNPM = require('hello-world-npm');
const HelloWorldNPM = require('hello-world-npm');

console.log(HelloWorldNPM());
