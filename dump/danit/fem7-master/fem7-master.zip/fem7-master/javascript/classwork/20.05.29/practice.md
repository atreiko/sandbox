https://codesandbox.io/s/tasj-js-dom-remove-ehnuh?file=/task/requirements.md
https://codesandbox.io/s/js-task-potter-o5kqi
https://codesandbox.io/s/task-js-dom-google-it-tpsrv
https://codesandbox.io/s/task-js-dom-shop-7ie1l
