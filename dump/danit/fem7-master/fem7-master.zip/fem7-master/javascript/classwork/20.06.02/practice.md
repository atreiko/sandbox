## Координаты
https://codesandbox.io/s/task-js-coordinates-6vmdm
решение: https://codesandbox.io/s/task-js-coordinates-solution-rv6tf?file=/task/requirements.md

## События

https://codesandbox.io/s/task-js-dom-tooltip-b4zs9?file=/task/task.js

решение https://codesandbox.io/s/task-js-dom-tooltip-solution-3g6s1?file=/task/task.js