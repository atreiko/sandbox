'use strict';
console.log(`not deferred script reporting: body is`, document.body);
