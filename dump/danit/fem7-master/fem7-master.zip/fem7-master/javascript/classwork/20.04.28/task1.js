const a = +prompt("write a number", "");
const b = +prompt("write a number", "");
const c = +prompt("write a number", "");

if (Number.isNaN()) {
}
alert((a + b + c) / 3);
