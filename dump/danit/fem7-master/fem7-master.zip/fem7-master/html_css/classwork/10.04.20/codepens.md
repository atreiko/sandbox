Таблицы https://codepen.io/cyberbiont/pen/KKdKJyQ

Text-shadow / border-shadow https://codepen.io/cyberbiont/pen/poJmPQg

Transforms https://codepen.io/cyberbiont/pen/abvzzNw

Font-awesome CDN https://cdnjs.com/libraries/font-awesome