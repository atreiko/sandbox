use `gulp` to run dev mode
use `gulp -p` to run production build
