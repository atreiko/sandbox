## Псевдоклассы

Cсылки: https://codepen.io/cyberbiont/pen/oNXmmwQ

...-of-type, ...-child, :not() https://codepen.io/cyberbiont/pen/MWwxmej

## Псевдоэлементы

::first-letter, ::first-line, ::selection https://codepen.io/cyberbiont/pen/MWwLLGE

::before, ::after https://codepen.io/cyberbiont/pen/XWbGWqQ

Пример использования псевдоклассов :hover, :focus-within для верстки выпадающего меню на чистом CSS  https://codepen.io/cyberbiont/pen/dyoaaEB