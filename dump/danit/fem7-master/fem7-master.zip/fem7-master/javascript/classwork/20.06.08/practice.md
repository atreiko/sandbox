[jquery-todo](https://codesandbox.io/s/task-js-jquery-todo-list-7kk1q) [решение](https://codesandbox.io/s/task-js-jquery-todo-list-solution-9kh89)

[jquery-scroll](https://codesandbox.io/s/task-js-jquery-scroll-4d2ib) [решение](https://codesandbox.io/s/task-js-jquery-scroll-solution-ivtir)

[jquery-tooltip](https://codesandbox.io/s/task-js-jquery-tooltip-nzhef) [решение](https://codesandbox.io/s/task-js-jquery-tooltip-solution-wiksd)