Шаблоны задач
[FizzBuzz](https://codesandbox.io/s/task-js-fizz-buzz-nl5sx)
[Numbers mod](https://codesandbox.io/s/task-js-numbers-mod-vc3r4)
[Print a pattern](https://codesandbox.io/s/task-js-print-pattern-cvn6n)
[Arithmetic progression](https://codesandbox.io/s/task-js-arithmetic-progression-2gicj)
[Arithmetic progression - решение](https://codesandbox.io/s/task-js-arithmetic-progression-solution-shwwx)
