## Задание

Сверстать страницу с анимацией, как на картинке [gif](animation_front-end_wars.gif). 

#### Технические требования к верстке:
- Анимация должна длиться 30 секунд, потом начинаться сначала

#### Текст (можно использовать свой вариант):

##### EPISODE 0
##### ATTACK OF THE FRONTEND

When there is no more hope. When Winter is coming. When the White Walkers prepare to break down the Wall and JAVA can no longer stop them ... <br><br>
Comes he - Javascript. Lord of untyped data and components, he does not give up technical tasks "to do nicely" and is not afraid of calculations on the user side. But he comes not alone, having 3 of his faithful friends with him: jQuery, React.js and Node.js.

#### Необязательное задание:
- Добавить на страницу аудио тег с треком-заставкой из [Star Wars](https://www.youtube.com/watch?v=EjMNNpIksaI) :)
