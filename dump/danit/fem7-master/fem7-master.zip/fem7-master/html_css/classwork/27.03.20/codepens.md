## Floats

Основной поток документа https://codepen.io/cyberbiont/pen/BaNGMdp

Картинка рядом с текстом https://codepen.io/cyberbiont/pen/WNvYPzX

Двухколоночная разметка https://codepen.io/cyberbiont/pen/abOQXar

Галерея картинок: https://codepen.io/cyberbiont/pen/jOPQJVQ

## Позиционирование

относительное https://codepen.io/cyberbiont/pen/NWqEmVr

абсолютное  https://codepen.io/cyberbiont/pen/bGdQJyp?editors=1100

sticky: https://codepen.io/cyberbiont/pen/BaNGEeo

fixed: https://codepen.io/cyberbiont/pen/JjdeVVa